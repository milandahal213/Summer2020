from spike.control import wait_for_seconds

print("Twinkle Twinkle")
# wait for 2 second (pause the program flow)
wait_for_seconds(2)
print("little star")
# wait for 1.5 seconds (pause the program flow)
wait_for_seconds(1.5)
print("how I wonder")
# wait for 0.5 seconds (pause the program flow)
wait_for_seconds(0.5)
print("where you are")